"""E7 Phase 2 guarded execution harness (design-only execution path).

Implements safe, sequential execution of the authoritative E7 v5
experiment matrix (results/e7/design_20261120/v5_final_reconciliation/
FINAL_RUN_MATRIX.csv). DRY-RUN IS THE DEFAULT: planning never loads
models, never initializes training, and never creates or modifies
experiment outputs. Actual execution requires the explicit CLI pair
``--execute --confirm-token <EXECUTE_CONFIRM_TOKEN>``.

This module deliberately imports only the Python standard library:
the dry-run path must not import or initialize any model-training
dependency (torch / transformers / peft are NOT imported here). The
real training callable is injected at execution time (``run_fn``), so
the harness itself stays training-agnostic and the dry-run path is
provably free of the model-training execution path.

Safety contract (v5 design + Phase 2 harness authorization):
- Matrix validation: exactly 22 outcome rows (19 NEW + 3 REUSE), unique
  IDs, valid policies/rank schedules/alphas/seeds/provenance;
  Resource-Aware future ranks must remain runtime-decided.
- Output protection: one unique directory per exec_id under the
  authorized output root; existing artifacts, completion markers, or
  manifests block execution; never delete, clean, or overwrite;
  atomic manifest writes; path-traversal and symlink-escape rejection.
- REUSE anchors: read-only references; existence + required artifacts +
  checksums recorded; missing/invalid anchors fail closed before any
  NEW run; never scheduled as training.
- Sequential execution: an execution lock admits exactly one harness
  instance per output root; states PLANNED/RUNNING/COMPLETED/FAILED/
  INTERRUPTED; COMPLETED only after training + evaluation success,
  artifact presence + integrity, and atomic manifest finalization;
  interrupted runs are never mistaken for completed ones and are never
  auto-restarted; ambiguous state fails closed.
"""

from __future__ import annotations

import argparse
import csv
import dataclasses
import datetime as _dt
import hashlib
import json
import os
import re
import socket
import sys
import tempfile
from pathlib import Path
from typing import Callable, Iterator

__all__ = [
    "EXECUTE_CONFIRM_TOKEN",
    "STATES",
    "AnchorValidationError",
    "AnchorRecord",
    "ExecutionHarness",
    "HarnessError",
    "LockError",
    "MatrixValidationError",
    "OutputSafetyError",
    "RunSpec",
    "StateError",
    "Telemetry",
    "load_and_validate_matrix",
    "main",
]

EXECUTE_CONFIRM_TOKEN = "i-authorize-e7-phase2-execution"
STATES = ("PLANNED", "RUNNING", "COMPLETED", "FAILED", "INTERRUPTED")
TERMINAL_OK = "COMPLETED"

ALLOWED_POLICIES = {"Static-R4", "Static-R8", "Static-R9", "Static-R16",
                    "Static-R32", "Grow", "Reduce", "Resource-Aware"}
ALLOWED_PHASES = {"static-baseline", "dynamic-rank", "dynamic-rank-pilot"}
ALLOWED_SEEDS = {42, 43, 44}
EXEC_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
ANCHOR_REQUIRED_FILES = ("event_metrics.json", "resource_metrics.json",
                         "continual_learning_matrix.csv.json")
MANIFEST_NAME = "manifest.json"
COMPLETION_MARKER_NAME = "completion_marker.json"
LOCK_NAME = ".execution_lock.json"

MATRIX_COUNTS = {"total": 22, "new": 19, "reuse": 3}
MATRIX_POLICY_SEEDS = {
    "Static-R4": [42, 43, 44], "Static-R8": [42, 43, 44],
    "Static-R9": [42, 43, 44], "Static-R16": [42, 43, 44],
    "Static-R32": [42, 43, 44], "Grow": [42, 43, 44],
    "Reduce": [42, 43, 44], "Resource-Aware": [42],
}


class HarnessError(Exception):
    """Base class for all harness failures (fail closed)."""


class MatrixValidationError(HarnessError):
    pass


class OutputSafetyError(HarnessError):
    pass


class AnchorValidationError(HarnessError):
    pass


class LockError(HarnessError):
    pass


class StateError(HarnessError):
    pass


def _now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def _atomic_write_json(path: Path, payload: dict) -> None:
    """Atomic JSON write: temp file in the same directory, fsync, os.replace."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp_", suffix=".json")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, path)
    except BaseException:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


@dataclasses.dataclass(frozen=True)
class Telemetry:
    """Logging fields prepared for eventual (authorized) execution."""
    wall_start: str | None = None
    wall_end: str | None = None
    training_s: float | None = None
    evaluation_s: float | None = None
    checkpoint_serialize_s: float | None = None
    rank_transition_s: float | None = None
    return_code: int | None = None
    peak_rss_mb: float | None = None
    final_rank_schedule: tuple | None = None
    final_eval_metrics: dict | None = None
    artifact_checksums: dict | None = None

    def to_dict(self) -> dict:
        d = dataclasses.asdict(self)
        d["final_rank_schedule"] = list(self.final_rank_schedule) if self.final_rank_schedule else None
        return d


@dataclasses.dataclass(frozen=True)
class RunSpec:
    exec_id: str
    policy: str
    phase: str
    seed: int
    row_type: str                      # NEW | REUSE
    initial_rank: int | str
    event_ranks: tuple                 # ints, or "runtime" for RA events 2-3
    event_alphas: tuple
    depth: str
    budget_per_event: int
    resource_aware_pilot: bool
    reuse_source: str                  # '' for NEW
    decision_policy_id: str
    decision_thresholds: str
    row: dict                          # original matrix row

    @property
    def config_hash(self) -> str:
        canonical = json.dumps(self.row, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode()).hexdigest()

    @property
    def anchor_path(self) -> Path | None:
        if self.row_type != "REUSE" or not self.reuse_source:
            return None
        raw = self.reuse_source.split(" (")[0].strip()  # strip annotation suffix
        return Path(raw)


@dataclasses.dataclass(frozen=True)
class AnchorRecord:
    exec_id: str
    path: str
    files: tuple
    checksums: dict

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)


def _int_field(row: dict, key: str, exec_id: str) -> int:
    try:
        return int(row[key])
    except (KeyError, TypeError, ValueError) as e:
        raise MatrixValidationError(f"{exec_id}: field {key!r} must be an integer "
                                    f"(got {row.get(key)!r})") from e


def validate_row(row: dict) -> RunSpec:
    """Validate one matrix record; raise MatrixValidationError on any defect."""
    exec_id = row.get("exec_id", "<missing>")
    if "exec_id" not in row or row.get("exec_id") is None or not row["exec_id"]:
        raise MatrixValidationError("malformed record: missing exec_id")
    missing = [k for k in ("phase", "policy", "depth", "seed", "budget_per_event",
                           "reuse_or_new", "decision_policy_id")
               if row.get(k) is None]
    if missing:
        raise MatrixValidationError(f"{exec_id}: missing required fields {missing}")

    if not EXEC_ID_RE.match(row["exec_id"]) or ".." in row["exec_id"]:
        raise MatrixValidationError(f"{exec_id}: invalid exec_id format")

    policy, phase = row["policy"], row["phase"]
    if policy not in ALLOWED_POLICIES:
        raise MatrixValidationError(f"{exec_id}: unknown policy {policy!r}")
    if phase not in ALLOWED_PHASES:
        raise MatrixValidationError(f"{exec_id}: unknown phase {phase!r}")

    row_type = row["reuse_or_new"]
    if row_type not in ("NEW", "REUSE"):
        raise MatrixValidationError(f"{exec_id}: reuse_or_new must be NEW or REUSE")

    seed = _int_field(row, "seed", exec_id)
    if seed not in ALLOWED_SEEDS:
        raise MatrixValidationError(f"{exec_id}: seed {seed} not in {sorted(ALLOWED_SEEDS)}")
    if MATRIX_POLICY_SEEDS[policy] != [s for s in MATRIX_POLICY_SEEDS[policy] if s == seed] and \
            seed not in MATRIX_POLICY_SEEDS[policy]:
        raise MatrixValidationError(f"{exec_id}: seed {seed} not allowed for policy {policy}")

    budget = _int_field(row, "budget_per_event", exec_id)
    if budget != 500:
        raise MatrixValidationError(f"{exec_id}: budget_per_event must be 500 (b500 protocol)")
    if row["depth"] != "D100":
        raise MatrixValidationError(f"{exec_id}: depth must be D100")

    ranks = [row[f"event_{i}_rank"] for i in (1, 2, 3)]
    alphas = [row[f"event_{i}_alpha"] for i in (1, 2, 3)]

    if policy.startswith("Static-"):
        r = _int_field(row, "initial_rank", exec_id)
        if ranks != [str(r)] * 3:
            raise MatrixValidationError(f"{exec_id}: static ranks must be fixed at {r}")
        for k, j in zip(ranks, alphas):
            if int(j) != 2 * int(k):
                raise MatrixValidationError(f"{exec_id}: alpha {j} != 2 * rank {k}")
    elif policy == "Grow":
        if ranks != ["4", "8", "16"] or alphas != ["8", "16", "32"]:
            raise MatrixValidationError(f"{exec_id}: Grow must be 4->8->16 with alphas 8/16/32")
    elif policy == "Reduce":
        if ranks != ["16", "8", "4"] or alphas != ["32", "16", "8"]:
            raise MatrixValidationError(f"{exec_id}: Reduce must be 16->8->4 with alphas 32/16/8")
    elif policy == "Resource-Aware":
        if ranks[0] != "4" or alphas[0] != "8":
            raise MatrixValidationError(f"{exec_id}: Resource-Aware must start at rank 4 / alpha 8")
        if ranks[1:] != ["runtime", "runtime"] or alphas[1:] != ["runtime", "runtime"]:
            raise MatrixValidationError(
                f"{exec_id}: Resource-Aware future ranks/alphas must be 'runtime' "
                f"(hardcoded trajectories are rejected)")
        if row.get("decision_policy_id") != "convergence_signal":
            raise MatrixValidationError(f"{exec_id}: Resource-Aware decision_policy_id must be "
                                        f"'convergence_signal'")
    else:  # pragma: no cover - policy already restricted to known set
        raise MatrixValidationError(f"{exec_id}: unhandled policy {policy!r}")

    if row_type == "NEW" and row.get("reuse_source", "").strip():
        raise MatrixValidationError(f"{exec_id}: NEW row must have empty reuse_source")
    if row_type == "REUSE" and not row.get("reuse_source", "").strip():
        raise MatrixValidationError(f"{exec_id}: REUSE row must reference its anchor artifact")

    return RunSpec(
        exec_id=row["exec_id"], policy=policy, phase=phase, seed=seed,
        row_type=row_type, initial_rank=row["initial_rank"],
        event_ranks=tuple(ranks), event_alphas=tuple(alphas),
        depth=row["depth"], budget_per_event=budget,
        resource_aware_pilot=policy == "Resource-Aware",
        reuse_source=row.get("reuse_source", ""),
        decision_policy_id=row["decision_policy_id"],
        decision_thresholds=row.get("decision_thresholds", ""),
        row=dict(row),
    )


def load_and_validate_matrix(matrix_path: Path) -> list[RunSpec]:
    """Parse and fully validate the authoritative matrix; fail closed."""
    with open(matrix_path, newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    if len(rows) != MATRIX_COUNTS["total"]:
        raise MatrixValidationError(
            f"matrix must have exactly {MATRIX_COUNTS['total']} outcome rows, got {len(rows)}")
    specs = [validate_row(r) for r in rows]
    ids = [s.exec_id for s in specs]
    if len(set(ids)) != len(ids):
        dupes = sorted({i for i in ids if ids.count(i) > 1})
        raise MatrixValidationError(f"duplicate run IDs: {dupes}")
    new = [s for s in specs if s.row_type == "NEW"]
    reuse = [s for s in specs if s.row_type == "REUSE"]
    if len(new) != MATRIX_COUNTS["new"] or len(reuse) != MATRIX_COUNTS["reuse"]:
        raise MatrixValidationError(
            f"matrix composition must be {MATRIX_COUNTS['new']} NEW + "
            f"{MATRIX_COUNTS['reuse']} REUSE, got {len(new)} + {len(reuse)}")
    for policy, seeds in MATRIX_POLICY_SEEDS.items():
        got = sorted(s.seed for s in specs if s.policy == policy)
        if got != sorted(seeds):
            raise MatrixValidationError(f"policy {policy}: expected seeds {seeds}, got {got}")
    return specs


def validate_anchor(spec: RunSpec, repo_root: Path) -> AnchorRecord:
    """Validate a REUSE anchor read-only: existence, required files, checksums."""
    anchor = spec.anchor_path
    if anchor is None:
        raise AnchorValidationError(f"{spec.exec_id}: REUSE row has no anchor path")
    full = (repo_root / anchor)
    if not full.is_dir():
        raise AnchorValidationError(f"{spec.exec_id}: anchor {anchor} does not exist")
    files, checksums = [], {}
    for name in ANCHOR_REQUIRED_FILES:
        p = full / name
        if not p.is_file():
            raise AnchorValidationError(f"{spec.exec_id}: anchor {anchor} missing required "
                                        f"artifact {name!r}")
        files.append(name)
        checksums[name] = _sha256_file(p)
    return AnchorRecord(exec_id=spec.exec_id, path=str(anchor), files=tuple(files),
                        checksums=checksums)


def _resolve_within(root: Path, candidate: Path) -> Path:
    """Resolve candidate and verify it stays inside root (no traversal/escape)."""
    root_res = root.resolve()
    cand_res = candidate.resolve()
    if cand_res != root_res and root_res not in cand_res.parents:
        raise OutputSafetyError(
            f"resolved path {cand_res} escapes authorized output root {root_res}")
    return cand_res


def resolve_output_dir(output_root: Path, exec_id: str) -> Path:
    """Safe per-run directory path under the authorized root."""
    if not EXEC_ID_RE.match(exec_id) or ".." in exec_id:
        raise OutputSafetyError(f"invalid exec_id {exec_id!r} (path traversal rejected)")
    return _resolve_within(output_root, output_root / exec_id)


class _ExecutionLock:
    """Single-instance lock for an output root (O_CREAT|O_EXCL, PID recorded).

    Stale locks (owning PID no longer alive) are DETECTED and REPORTED but
    never silently deleted — the operator removes them explicitly.
    """

    def __init__(self, output_root: Path):
        self.path = output_root / LOCK_NAME
        self._held = False

    def __enter__(self) -> "_ExecutionLock":
        output_root = self.path.parent
        output_root.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            try:
                info = json.loads(self.path.read_text())
            except (OSError, json.JSONDecodeError):
                info = {"note": "unreadable lock"}
            pid = info.get("pid")
            alive = False
            if isinstance(pid, int) and pid > 0:
                try:
                    os.kill(pid, 0)
                    alive = True
                except ProcessLookupError:
                    alive = False
                except PermissionError:
                    alive = True  # exists, owned by another user
            kind = "active" if alive else "STALE"
            raise LockError(
                f"{kind} execution lock present at {self.path} (info={info}); "
                f"a second harness instance may not use this output root. "
                f"Stale locks must be removed manually by the operator "
                f"(never auto-deleted).")
        payload = {"pid": os.getpid(), "host": socket.gethostname(),
                   "acquired_at": _now(), "harness": "e7-phase2"}
        try:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError as e:
            raise LockError(f"execution lock already present at {self.path}") from e
        with os.fdopen(fd, "w") as f:
            json.dump(payload, f)
        self._held = True
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._held and self.path.exists():
            self.path.unlink()
        self._held = False


@dataclasses.dataclass
class PlannedRun:
    exec_id: str
    policy: str
    seed: int
    row_type: str
    event_ranks: tuple
    event_alphas: tuple
    output_path: str            # per-run dir for NEW; anchor path for REUSE
    config_hash: str
    reuse_source: str
    action: str                 # "train" for NEW; "read-only reference" for REUSE

    def to_dict(self) -> dict:
        d = dataclasses.asdict(self)
        d["event_ranks"] = list(self.event_ranks)
        d["event_alphas"] = list(self.event_alphas)
        return d


class ExecutionHarness:
    """Guarded, sequential executor for the E7 v5 matrix.

    ``dry_run()`` is side-effect free for experiment outputs and never
    imports the model-training path. ``execute()`` requires the explicit
    confirmation token and an injected ``run_fn`` training callable; it is
    NEVER invoked by this task.
    """

    def __init__(self, matrix_path: Path, output_root: Path,
                 repo_root: Path | None = None,
                 run_fn: Callable[[RunSpec, Path], dict] | None = None):
        self.matrix_path = Path(matrix_path)
        self.output_root = Path(output_root)
        self.repo_root = Path(repo_root) if repo_root else Path.cwd()
        self.run_fn = run_fn
        self._specs: list[RunSpec] | None = None
        self._anchors: dict[str, AnchorRecord] = {}
        self._interrupted = False

    # ------------------------------------------------------------------ #
    # matrix + anchors                                                    #
    # ------------------------------------------------------------------ #

    def specs(self) -> list[RunSpec]:
        if self._specs is None:
            self._specs = load_and_validate_matrix(self.matrix_path)
        return self._specs

    def validate_anchors(self) -> dict[str, AnchorRecord]:
        """Fail closed BEFORE any NEW run if any anchor is missing/invalid."""
        records = {}
        for spec in self.specs():
            if spec.row_type == "REUSE":
                records[spec.exec_id] = validate_anchor(spec, self.repo_root)
        self._anchors = records
        return records

    def _validate_output_root(self) -> Path:
        authorized = (self.repo_root / "results" / "e7").resolve()
        root_res = self.output_root.resolve()
        if root_res != authorized and authorized not in root_res.parents:
            raise OutputSafetyError(
                f"output root {self.output_root} resolves outside the authorized "
                f"E7 experiment tree {authorized}")
        if self.output_root.exists() and self.output_root.is_symlink():
            raise OutputSafetyError("output root must not be a symlink")
        return self.output_root

    # ------------------------------------------------------------------ #
    # dry run                                                             #
    # ------------------------------------------------------------------ #

    def dry_run(self) -> list[PlannedRun]:
        """Build the ordered execution plan. Creates/modify NOTHING in the
        output root; never touches anchors; never imports the training path."""
        self._validate_output_root()
        specs = self.specs()
        self.validate_anchors()  # read-only existence + checksums
        plan = []
        for spec in specs:
            if spec.row_type == "REUSE":
                out = str(spec.anchor_path)
                action = "read-only reference"
            else:
                out = str(resolve_output_dir(self.output_root, spec.exec_id))
                action = "train"
            plan.append(PlannedRun(
                exec_id=spec.exec_id, policy=spec.policy, seed=spec.seed,
                row_type=spec.row_type, event_ranks=spec.event_ranks,
                event_alphas=spec.event_alphas, output_path=out,
                config_hash=spec.config_hash, reuse_source=spec.reuse_source,
                action=action))
        return plan

    # ------------------------------------------------------------------ #
    # guarded execution (NOT invoked in this task)                        #
    # ------------------------------------------------------------------ #

    def execute(self, confirm_token: str) -> list[PlannedRun]:
        """Execute the plan sequentially under the execution lock.

        Requires the explicit confirmation token; fails closed otherwise.
        REUSE rows are never scheduled as training.
        """
        if confirm_token != EXECUTE_CONFIRM_TOKEN:
            raise HarnessError(
                "execution refused: missing or incorrect confirmation token "
                f"(expected --confirm-token {EXECUTE_CONFIRM_TOKEN!r})")
        if self.run_fn is None:
            raise HarnessError("execution refused: no run_fn training callable injected")
        self._validate_output_root()
        self.validate_anchors()  # fail closed before any NEW run
        plan = self.dry_run()

        with _ExecutionLock(self.output_root):
            results = []
            for spec, planned in zip(self.specs(), plan):
                if spec.row_type == "REUSE":
                    results.append(planned)  # read-only reference; never trained
                    continue
                run_dir = resolve_output_dir(self.output_root, spec.exec_id)
                self._guard_fresh_dir(run_dir, spec)
                run_dir.mkdir(parents=True, exist_ok=False)
                manifest = {
                    "exec_id": spec.exec_id, "config_hash": spec.config_hash,
                    "state": "RUNNING", "created_at": _now(), "updated_at": _now(),
                    "source_row": spec.row, "anchor": None,
                    "telemetry": Telemetry(wall_start=_now(),
                                           final_rank_schedule=spec.event_ranks).to_dict(),
                }
                _atomic_write_json(run_dir / MANIFEST_NAME, manifest)
                try:
                    telemetry = self.run_fn(spec, run_dir)  # injected callable
                    self._finalize_completed(run_dir, spec, manifest, telemetry)
                except KeyboardInterrupt:
                    self._mark_interrupted(run_dir, spec, manifest,
                                           reason="KeyboardInterrupt")
                    raise
                except Exception as e:  # noqa: BLE001
                    self._mark_failed(run_dir, spec, manifest, reason=repr(e))
                    results.append(planned)
                    continue  # record failure; next run decides via guard
                results.append(planned)
        return results

    # ------------------------------------------------------------------ #
    # state machine                                                       #
    # ------------------------------------------------------------------ #

    def _guard_fresh_dir(self, run_dir: Path, spec: RunSpec) -> None:
        if run_dir.exists():
            has_marker = (run_dir / COMPLETION_MARKER_NAME).exists()
            has_manifest = (run_dir / MANIFEST_NAME).exists()
            has_content = any(run_dir.iterdir())
            if has_marker or has_manifest or has_content:
                raise OutputSafetyError(
                    f"{spec.exec_id}: refusing to execute — output directory "
                    f"{run_dir} already contains artifacts"
                    + (" and a completion marker" if has_marker else "")
                    + (" and a prior execution manifest" if has_manifest else "")
                    + "; existing run directories are never overwritten, "
                      "cleaned, or reused")

    def _read_manifest(self, run_dir: Path) -> dict:
        p = run_dir / MANIFEST_NAME
        if not p.is_file():
            raise StateError(f"no manifest at {p} (fail closed on ambiguous state)")
        try:
            return json.loads(p.read_text())
        except json.JSONDecodeError as e:
            raise StateError(f"corrupt manifest at {p}: {e}") from e

    def _update_state(self, run_dir: Path, manifest: dict, state: str,
                      **extra) -> None:
        if state not in STATES:
            raise StateError(f"unknown state {state!r}")
        manifest["state"] = state
        manifest["updated_at"] = _now()
        manifest.update(extra)
        _atomic_write_json(run_dir / MANIFEST_NAME, manifest)

    def _finalize_completed(self, run_dir: Path, spec: RunSpec,
                            manifest: dict, telemetry: dict) -> None:
        """COMPLETED only after artifacts exist, integrity passes, and the
        final manifest + completion marker are written atomically."""
        if manifest.get("state") != "RUNNING":
            raise StateError(
                f"{spec.exec_id}: cannot mark COMPLETED from state "
                f"{manifest.get('state')!r} (incomplete/failed/interrupted runs "
                f"are never silently promoted)")
        required = ["execution_summary.json", "final_eval.json", "predictions"]
        artifacts = {}
        for name in required:
            p = run_dir / name
            if not p.exists():
                raise StateError(f"{spec.exec_id}: required artifact {name!r} missing; "
                                 f"run cannot be COMPLETED")
            artifacts[name] = _sha256_file(p) if p.is_file() else "dir"
        telemetry = dict(telemetry or {})
        telemetry.setdefault("return_code", 0)
        telemetry["artifact_checksums"] = artifacts
        self._update_state(run_dir, manifest, TERMINAL_OK, telemetry=telemetry,
                           completed_at=_now())
        _atomic_write_json(run_dir / COMPLETION_MARKER_NAME, {
            "exec_id": spec.exec_id, "config_hash": spec.config_hash,
            "state": TERMINAL_OK, "completed_at": _now(),
            "artifacts": artifacts,
            "telemetry": telemetry,
        })

    def _mark_failed(self, run_dir: Path, spec: RunSpec, manifest: dict,
                     reason: str) -> None:
        self._update_state(run_dir, manifest, "FAILED",
                           failure_reason=reason, failed_at=_now())

    def _mark_interrupted(self, run_dir: Path, spec: RunSpec, manifest: dict,
                          reason: str) -> None:
        """Interrupted runs stay INTERRUPTED — distinguishable from COMPLETED,
        never auto-restarted (resume safety is not claimed or implemented)."""
        self._update_state(run_dir, manifest, "INTERRUPTED",
                           interruption_reason=reason, interrupted_at=_now())

    def inspect_state(self, run_dir: Path) -> dict:
        """Read-only inspection of a run's recorded state (operator aid)."""
        manifest = self._read_manifest(run_dir)
        marker = run_dir / COMPLETION_MARKER_NAME
        return {
            "exec_id": manifest.get("exec_id"),
            "state": manifest.get("state"),
            "completion_marker_present": marker.exists(),
            "failure_reason": manifest.get("failure_reason"),
            "interruption_reason": manifest.get("interruption_reason"),
            "updated_at": manifest.get("updated_at"),
        }


def _plan_markdown(plan: list[PlannedRun], totals_note: str) -> str:
    lines = [
        "# E7 Phase 2 — Dry-Run Execution Plan",
        "",
        "Generated by the guarded harness in **dry-run mode** (default).",
        "**No experiment was executed. No output directory was created or",
        "modified. No model was loaded.**",
        "",
        "| # | exec_id | policy | seed | type | ranks | alphas | output path | action |",
        "|---|---------|--------|------|------|-------|--------|-------------|--------|",
    ]
    for i, p in enumerate(plan, 1):
        ranks = "->".join(str(r) for r in p.event_ranks)
        alphas = "->".join(str(a) for a in p.event_alphas)
        lines.append(f"| {i} | {p.exec_id} | {p.policy} | {p.seed} | {p.row_type} "
                     f"| {ranks} | {alphas} | `{p.output_path}` | {p.action} |")
    n_new = sum(1 for p in plan if p.row_type == "NEW")
    n_reuse = sum(1 for p in plan if p.row_type == "REUSE")
    lines += [
        "",
        f"**Plan totals: {len(plan)} rows = {n_new} NEW + {n_reuse} REUSE.** "
        f"{totals_note}",
        "",
        "REUSE rows are read-only references to existing E2 Static-R8 anchor",
        "artifacts; they are never scheduled as training. NEW rows map to",
        "unique per-run directories under the authorized output root and are",
        "executed strictly sequentially under the execution lock after",
        "explicit authorization (`--execute --confirm-token ...`).",
    ]
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="E7 Phase 2 guarded execution harness")
    ap.add_argument("--matrix", type=Path,
                    default=Path("results/e7/design_20261120/v5_final_reconciliation/FINAL_RUN_MATRIX.csv"))
    ap.add_argument("--output-root", type=Path, default=Path("results/e7/execution_20261121"))
    ap.add_argument("--repo-root", type=Path, default=Path.cwd())
    ap.add_argument("--plan-out", type=Path, default=None,
                    help="write machine-readable plan (JSON) + markdown to this directory")
    mode = ap.add_mutually_exclusive_group()
    mode.add_argument("--dry-run", action="store_true", default=True,
                      help="(default) plan only; no execution, no outputs")
    mode.add_argument("--execute", action="store_true",
                      help="execute (requires --confirm-token; NOT authorized yet)")
    ap.add_argument("--confirm-token", type=str, default="")
    args = ap.parse_args(argv)

    harness = ExecutionHarness(args.matrix, args.output_root, repo_root=args.repo_root)
    plan = harness.dry_run()
    totals_note = ("Validated against the authoritative v5 matrix "
                   "(22 rows = 19 NEW + 3 REUSE; anchors verified read-only).")
    md = _plan_markdown(plan, totals_note)
    print(md)
    if args.plan_out is not None:
        args.plan_out.mkdir(parents=True, exist_ok=True)
        (args.plan_out / "DRY_RUN_PLAN.md").write_text(md)
        _atomic_write_json(args.plan_out / "DRY_RUN_PLAN.json", {
            "generated_at": _now(),
            "mode": "DRY-RUN",
            "executed": False,
            "statement": "No experiment was executed. No output directory was "
                         "created or modified. No model was loaded.",
            "matrix": str(args.matrix),
            "output_root_planned": str(args.output_root),
            "totals": {"rows": len(plan),
                       "new": sum(1 for p in plan if p.row_type == "NEW"),
                       "reuse": sum(1 for p in plan if p.row_type == "REUSE")},
            "anchors": {k: v.to_dict() for k, v in harness._anchors.items()},
            "plan": [p.to_dict() for p in plan],
        })
    if args.execute:
        # Guarded path — requires the token; refused otherwise.
        harness.execute(args.confirm_token)
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
