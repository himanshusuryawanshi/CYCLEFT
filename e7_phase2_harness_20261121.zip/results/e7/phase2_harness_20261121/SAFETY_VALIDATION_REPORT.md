# E7 Phase 2 — Safety Validation Report

Date: 2026-11-21. Evidence source: `tests/test_e7_harness.py` (24 tests,
all passed, exit 0) + dry-run verification. Synthetic artifacts in temp
directories only; execution functions mocked; real training never invoked.

## Required safety scenarios — all validated

| # | Scenario | Test | Result |
|---|---|---|---|
| 1 | Valid 22-row matrix → 22-row plan | `test_1_valid_matrix_generates_22_row_plan` | PASS |
| 2 | Exactly 19 rows NEW | `test_2_exactly_19_new` | PASS |
| 3 | Exactly 3 rows REUSE | `test_3_exactly_3_reuse` | PASS |
| 4 | Duplicate run IDs rejected | `test_4_duplicate_run_ids_rejected` | PASS |
| 5 | Missing required fields rejected | `test_5_missing_required_fields_rejected` | PASS (unit + CSV-shift cases) |
| 6 | Invalid α/rank rejected | `test_6_invalid_alpha_rank_rejected` | PASS |
| 7 | Hardcoded future Resource-Aware ranks rejected | `test_7_hardcoded_future_resource_aware_ranks_rejected` | PASS |
| 8 | Missing/invalid REUSE anchor fails closed (before any NEW run) | `test_8_missing_anchor_fails_closed` | PASS (nonexistent + missing-artifact cases; no output content created) |
| 9 | Existing NEW output dir blocks execution | `test_9_existing_new_output_dir_blocks_execution` | PASS (dir untouched) |
| 10 | Existing completion marker blocks execution | `test_10_existing_completion_marker_blocks_execution` | PASS |
| 11 | Incomplete run cannot be COMPLETED | `test_11_incomplete_run_cannot_be_completed` | PASS (PLANNED refused; RUNNING w/ missing artifacts refused) |
| 12 | INTERRUPTED ≠ COMPLETED | `test_12_interrupted_not_mistaken_for_completed` | PASS (direct + end-to-end KeyboardInterrupt; marker absent) |
| 13 | Second runner cannot acquire active lock | `test_13_second_runner_cannot_acquire_active_lock` | PASS (releasable on normal exit) |
| 13b | Stale lock fails closed, never auto-deleted | `test_13b_stale_lock_fails_closed_not_deleted` | PASS |
| 14 | Path traversal rejected | `test_14_path_traversal_rejected` | PASS (`../e6-victim`, `ok/../../escape`) |
| 15 | Symlink escape rejected | `test_15_symlink_escape_rejected` | PASS |
| 16 | Dry-run modifies no anchors / outputs | `test_16_dry_run_modifies_nothing` | PASS (mtime+size snapshot equality; no output content) |
| 17 | Dry-run imports no model-training path | `test_17_dry_run_does_not_import_model_training_path` | PASS (subprocess: torch/transformers/peft/cycleft.e5/finetuning absent from sys.modules) |
| 18 | Dry-run cannot invoke training/evaluation | `test_18_dry_run_cannot_invoke_training_or_evaluation` | PASS (run_fn spy uncalled; wrong/empty token refused) |

## Additional protocol tests

| Test | Result |
|---|---|
| `test_completion_protocol_full_path` — COMPLETED requires artifacts + integrity + atomic manifest + marker with config_hash/telemetry | PASS |
| `test_run_manifest_contains_required_fields` — config hash present, stable across plan/spec | PASS |
| `test_reuse_rows_never_scheduled_for_training` — REUSE action is read-only reference; output path is the anchor, not the experiment root | PASS |
| `test_atomic_manifest_write_leaves_no_temp_files` — FAILED state written atomically, no `.tmp_` leftovers, reason recorded | PASS |
| `test_failed_run_then_next_run_still_guards` — FAILED run keeps state FAILED, no marker; later execution refused (never overwritten) | PASS |

## Failures encountered during development (all test-fixture bugs, fixed)

1. Synthetic matrix builder omitted `seed=str(seed)` (all rows seed 42) —
   builder fixed; harness correctly rejected the invalid composition.
2. Missing-fields check tested via CSV column deletion (columns shift);
   replaced with a precise `validate_row` unit check + harness hardened
   to reject None-valued required fields (a strengthening, not a loosening).
3. Two tests used output roots outside the authorized tree (correctly
   rejected by the harness) — fixture paths fixed.
4. Completion-protocol test forgot to create required artifacts (correctly
   refused) — fixture fixed.
5. Post-FAILED re-execution test expected progression; harness correctly
   raises `OutputSafetyError` — test aligned with the (correct) guard.

No safety test was weakened; two harness input-validation paths were
hardened during the process (None-required-field rejection).

## Operator guidance: FAILED / INTERRUPTED evidence

Inspect without destroying evidence:
`python -c "from cycleft.e7.execution_harness import ExecutionHarness; ...; print(h.inspect_state(run_dir))"`
returns state, failure/interruption reason, completion-marker presence,
and timestamps. Manifests, logs, and partial artifacts are never deleted
by the harness; stale lock removal is the only sanctioned manual action.
