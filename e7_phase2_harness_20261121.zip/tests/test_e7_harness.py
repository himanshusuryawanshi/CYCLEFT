"""E7 Phase 2 harness safety tests (synthetic artifacts, temp dirs only).

Never invokes real training: state-machine tests use mocked run_fn
callables. Dry-run tests prove the planning path creates/modify nothing
and never imports the model-training execution path.
"""

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cycleft.e7.execution_harness import (  # noqa: E402
    ANCHOR_REQUIRED_FILES,
    COMPLETION_MARKER_NAME,
    EXECUTE_CONFIRM_TOKEN,
    MANIFEST_NAME,
    AnchorValidationError,
    ExecutionHarness,
    HarnessError,
    LockError,
    MatrixValidationError,
    OutputSafetyError,
    StateError,
    load_and_validate_matrix,
)

V5_MATRIX = Path(__file__).resolve().parents[1] / (
    "results/e7/design_20261120/v5_final_reconciliation/FINAL_RUN_MATRIX.csv")


# ---------------------------------------------------------------------------
# synthetic matrix / anchor builders
# ---------------------------------------------------------------------------


def base_row(**over):
    row = {
        "exec_id": "e7-static-r4-s42", "phase": "static-baseline",
        "policy": "Static-R4", "initial_rank": "4",
        "allowed_ranks": "{4, 8, 16, 32}",
        "decision_policy_id": "none (predetermined fixed rank)",
        "decision_policy_version": "n/a", "decision_thresholds": "n/a",
        "event_1_rank": "4", "event_2_rank": "4", "event_3_rank": "4",
        "event_1_alpha": "8", "event_2_alpha": "8", "event_3_alpha": "8",
        "depth": "D100", "seed": "42", "budget_per_event": "500",
        "reuse_or_new": "NEW", "reuse_source": "",
        "est_train_s": "1300", "est_eval_s": "280",
        "rank_transition_overhead_s": "0", "model_load_s": "15",
        "ckpt_serialize_s": "4", "est_matrix_subtotal_s": "1580",
        "est_total_elapsed_s": "1599", "final_trainable_params": "851968",
        "resource_aware_pilot": "False", "scientific_question": "q",
    }
    row.update(over)
    return row


def build_valid_matrix(tmp_path: Path) -> Path:
    """A valid 22-row synthetic matrix (same composition as v5)."""
    rows = []
    for seed in (42, 43, 44):
        rows.append(base_row(seed=str(seed), exec_id=f"e7-static-r8-s{seed}", policy="Static-R8",
                             initial_rank="8", event_1_rank="8", event_2_rank="8",
                             event_3_rank="8", event_1_alpha="16", event_2_alpha="16",
                             event_3_alpha="16", reuse_or_new="REUSE",
                             reuse_source=f"anchor_{seed}"))
    for rank, alpha in ((4, 8), (9, 18), (16, 32), (32, 64)):
        for seed in (42, 43, 44):
            rows.append(base_row(seed=str(seed), exec_id=f"e7-static-r{rank}-s{seed}",
                                 policy=f"Static-R{rank}", initial_rank=str(rank),
                                 event_1_rank=str(rank), event_2_rank=str(rank),
                                 event_3_rank=str(rank), event_1_alpha=str(alpha),
                                 event_2_alpha=str(alpha), event_3_alpha=str(alpha),
                                 final_trainable_params=str(13312 * rank * 16)))
    for seed in (42, 43, 44):
        rows.append(base_row(seed=str(seed), exec_id=f"e7-grow-s{seed}", phase="dynamic-rank",
                             policy="Grow", initial_rank="4", event_1_rank="4",
                             event_2_rank="8", event_3_rank="16", event_1_alpha="8",
                             event_2_alpha="16", event_3_alpha="32",
                             rank_transition_overhead_s="10",
                             est_matrix_subtotal_s="1590",
                             est_total_elapsed_s="1609",
                             final_trainable_params="3407872"))
        rows.append(base_row(seed=str(seed), exec_id=f"e7-reduce-s{seed}", phase="dynamic-rank",
                             policy="Reduce", initial_rank="16", event_1_rank="16",
                             event_2_rank="8", event_3_rank="4", event_1_alpha="32",
                             event_2_alpha="16", event_3_alpha="8",
                             rank_transition_overhead_s="10",
                             est_matrix_subtotal_s="1590",
                             est_total_elapsed_s="1609",
                             final_trainable_params="851968"))
    rows.append(base_row(exec_id="e7-resource-aware-s42", phase="dynamic-rank-pilot",
                         policy="Resource-Aware", initial_rank="4",
                         decision_policy_id="convergence_signal",
                         decision_thresholds="up>=+0.05",
                         event_1_rank="4", event_2_rank="runtime",
                         event_3_rank="runtime", event_1_alpha="8",
                         event_2_alpha="runtime", event_3_alpha="runtime",
                         rank_transition_overhead_s="10",
                         est_matrix_subtotal_s="1590", est_total_elapsed_s="1609",
                         final_trainable_params="runtime (depends on selected ranks)",
                         resource_aware_pilot="True"))
    assert len(rows) == 22
    keys = list(rows[0].keys())
    p = tmp_path / "matrix.csv"
    with open(p, "w", newline="") as f:
        import csv
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    return p


def build_anchors(tmp_path: Path) -> Path:
    """Synthetic anchor artifacts matching the required E2 file set."""
    for seed in (42, 43, 44):
        d = tmp_path / f"anchor_{seed}"
        d.mkdir(parents=True, exist_ok=True)
        for name in ANCHOR_REQUIRED_FILES:
            (d / name).write_text(json.dumps({"seed": seed, "synthetic": True}))
    return tmp_path


@pytest.fixture
def env(tmp_path):
    matrix = build_valid_matrix(tmp_path)
    build_anchors(tmp_path)
    out_root = tmp_path / "results" / "e7" / "execution_test"
    out_root.mkdir(parents=True)
    harness = ExecutionHarness(matrix, out_root, repo_root=tmp_path)
    return harness, matrix, out_root, tmp_path


# ---------------------------------------------------------------------------
# 1-3: plan composition
# ---------------------------------------------------------------------------


def test_1_valid_matrix_generates_22_row_plan(env):
    harness, _, _, _ = env
    plan = harness.dry_run()
    assert len(plan) == 22
    assert all(p.action in ("train", "read-only reference") for p in plan)


def test_2_exactly_19_new(env):
    harness, *_ = env
    assert sum(1 for p in harness.dry_run() if p.row_type == "NEW") == 19


def test_3_exactly_3_reuse(env):
    harness, *_ = env
    assert sum(1 for p in harness.dry_run() if p.row_type == "REUSE") == 3


# ---------------------------------------------------------------------------
# 4-7: matrix validation
# ---------------------------------------------------------------------------


def _write_bad_matrix(tmp_path, mutate, filename="bad.csv"):
    src = build_valid_matrix(tmp_path / "ok_dir") if (tmp_path / "ok_dir").exists() \
        else build_valid_matrix(tmp_path)
    import csv
    with open(src, newline="") as f:
        rows = list(csv.DictReader(f))
    mutate(rows)
    p = tmp_path / filename
    with open(p, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return p


def test_4_duplicate_run_ids_rejected(tmp_path):
    def dup(rows):
        rows.append(dict(rows[0]))  # 23rd row with duplicate id
    p = _write_bad_matrix(tmp_path, dup)
    with pytest.raises(MatrixValidationError, match="exactly 22"):
        load_and_validate_matrix(p)


def test_5_missing_required_fields_rejected(tmp_path):
    from cycleft.e7.execution_harness import validate_row
    row = base_row()
    del row["seed"]
    with pytest.raises(MatrixValidationError, match="missing required fields"):
        validate_row(row)
    # None-valued fields (e.g. truncated CSV rows) are equally rejected
    row2 = base_row()
    row2["seed"] = None
    with pytest.raises(MatrixValidationError, match="missing required fields"):
        validate_row(row2)
    # a malformed CSV record (column shift from a dropped field) fails closed
    def drop(rows):
        del rows[5]["seed"]
    p = _write_bad_matrix(tmp_path, drop)
    with pytest.raises(MatrixValidationError):
        load_and_validate_matrix(p)


def test_6_invalid_alpha_rank_rejected(tmp_path):
    def bad_alpha(rows):
        rows[5]["event_1_alpha"] = "7"  # rank 4 -> alpha must be 8
    p = _write_bad_matrix(tmp_path, bad_alpha)
    with pytest.raises(MatrixValidationError, match="alpha"):
        load_and_validate_matrix(p)


def test_7_hardcoded_future_resource_aware_ranks_rejected(tmp_path):
    def hardcode(rows):
        ra = [r for r in rows if r["policy"] == "Resource-Aware"][0]
        ra["event_2_rank"], ra["event_3_rank"] = "8", "16"
        ra["event_2_alpha"], ra["event_3_alpha"] = "16", "32"
    p = _write_bad_matrix(tmp_path, hardcode)
    with pytest.raises(MatrixValidationError, match="runtime"):
        load_and_validate_matrix(p)


# ---------------------------------------------------------------------------
# 8: anchors fail closed
# ---------------------------------------------------------------------------


def test_8_missing_anchor_fails_closed(tmp_path):
    matrix = build_valid_matrix(tmp_path)  # no anchors built
    out_root = tmp_path / "results" / "e7" / "out"
    out_root.mkdir(parents=True)
    harness = ExecutionHarness(matrix, out_root, repo_root=tmp_path)
    with pytest.raises(AnchorValidationError, match="does not exist"):
        harness.dry_run()
    # and even with one anchor missing among three
    build_anchors(tmp_path)
    (tmp_path / "anchor_43" / ANCHOR_REQUIRED_FILES[0]).unlink()
    with pytest.raises(AnchorValidationError, match="missing required artifact"):
        harness.dry_run()
    assert not any(out_root.iterdir()), "failed dry-run must create no output content"


# ---------------------------------------------------------------------------
# 9-12: output protection + state machine (mocked run_fn; never real training)
# ---------------------------------------------------------------------------


def _ok_run_fn(tmp_path):
    def run_fn(spec, run_dir):
        (run_dir / "predictions").mkdir()
        (run_dir / "execution_summary.json").write_text('{"ok": true}')
        (run_dir / "final_eval.json").write_text('{"em": 0.1}')
        return {"return_code": 0}
    return run_fn


def test_9_existing_new_output_dir_blocks_execution(env):
    harness, matrix, out_root, tmp_path = env
    victim = out_root / "e7-static-r4-s42"
    victim.mkdir()
    (victim / "stale_artifact.bin").write_text("x")
    harness2 = ExecutionHarness(matrix, out_root, repo_root=tmp_path, run_fn=_ok_run_fn(tmp_path))
    from cycleft.e7.execution_harness import EXECUTE_CONFIRM_TOKEN as TOK
    with pytest.raises(OutputSafetyError, match="refusing to execute"):
        harness2.execute(TOK)
    # directory untouched
    assert (victim / "stale_artifact.bin").read_text() == "x"


def test_10_existing_completion_marker_blocks_execution(env):
    harness, matrix, out_root, tmp_path = env
    victim = out_root / "e7-static-r4-s42"
    victim.mkdir()
    (victim / COMPLETION_MARKER_NAME).write_text('{"state": "COMPLETED"}')
    harness2 = ExecutionHarness(matrix, out_root, repo_root=tmp_path, run_fn=_ok_run_fn(tmp_path))
    with pytest.raises(OutputSafetyError, match="completion marker"):
        harness2.execute(EXECUTE_CONFIRM_TOKEN)


def test_11_incomplete_run_cannot_be_completed(env):
    harness, _, out_root, tmp_path = env
    run_dir = out_root / "e7-static-r4-s42"
    run_dir.mkdir(parents=True)
    manifest = {"exec_id": "e7-static-r4-s42", "state": "PLANNED"}
    (run_dir / MANIFEST_NAME).write_text(json.dumps(manifest))
    spec = harness.specs()[0]
    with pytest.raises(StateError, match="cannot mark COMPLETED"):
        harness._finalize_completed(run_dir, spec, manifest, telemetry={})
    # also: RUNNING state but missing required artifacts -> fails integrity
    manifest["state"] = "RUNNING"
    (run_dir / MANIFEST_NAME).write_text(json.dumps(manifest))
    with pytest.raises(StateError, match="required artifact"):
        harness._finalize_completed(run_dir, spec, manifest, telemetry={})
    rec = harness.inspect_state(run_dir)
    assert rec["state"] == "RUNNING" and rec["completion_marker_present"] is False


def test_12_interrupted_not_mistaken_for_completed(env):
    harness, matrix, out_root, tmp_path = env
    run_dir = out_root / "e7-static-r4-s42"
    run_dir.mkdir(parents=True)
    manifest = {"exec_id": "e7-static-r4-s42", "state": "RUNNING"}
    (run_dir / MANIFEST_NAME).write_text(json.dumps(manifest))
    spec = harness.specs()[0]
    harness._mark_interrupted(run_dir, spec, manifest, reason="SIGTERM")
    rec = harness.inspect_state(run_dir)
    assert rec["state"] == "INTERRUPTED"
    assert rec["completion_marker_present"] is False
    with pytest.raises(StateError, match="cannot mark COMPLETED"):
        harness._finalize_completed(run_dir, spec, manifest, telemetry={})

    # end-to-end: run_fn raising KeyboardInterrupt leaves INTERRUPTED, no marker
    # (test-only cleanup of the fixture dir created above; the harness itself
    # never deletes run directories)
    import shutil
    shutil.rmtree(run_dir)
    def interrupted_fn(spec, run_dir):
        (run_dir / "predictions").mkdir()
        raise KeyboardInterrupt
    h2 = ExecutionHarness(matrix, out_root, repo_root=tmp_path, run_fn=interrupted_fn)
    with pytest.raises(KeyboardInterrupt):
        h2.execute(EXECUTE_CONFIRM_TOKEN)
    rec = harness.inspect_state(out_root / "e7-static-r4-s42")
    assert rec["state"] == "INTERRUPTED" and not rec["completion_marker_present"]


# ---------------------------------------------------------------------------
# 13-15: locks, traversal, symlinks
# ---------------------------------------------------------------------------


def test_13_second_runner_cannot_acquire_active_lock(env):
    harness, _, out_root, tmp_path = env
    from cycleft.e7.execution_harness import _ExecutionLock
    with _ExecutionLock(out_root):
        with pytest.raises(LockError, match="second harness instance|already present"):
            with _ExecutionLock(out_root):
                pass
    # released on normal exit -> reacquirable
    with _ExecutionLock(out_root):
        pass


def test_13b_stale_lock_fails_closed_not_deleted(env):
    harness, _, out_root, _ = env
    from cycleft.e7.execution_harness import _ExecutionLock
    lock_path = out_root / ".execution_lock.json"
    lock_path.write_text(json.dumps({"pid": 999999999, "host": "gone"}))
    with pytest.raises(LockError, match="STALE"):
        with _ExecutionLock(out_root):
            pass
    assert lock_path.exists(), "stale lock must not be silently deleted"


def test_14_path_traversal_rejected(env):
    harness, _, _, _ = env
    from cycleft.e7.execution_harness import resolve_output_dir
    with pytest.raises(OutputSafetyError, match="traversal|invalid exec_id"):
        resolve_output_dir(harness.output_root, "../e6-victim")
    with pytest.raises(OutputSafetyError):
        resolve_output_dir(harness.output_root, "ok/../../escape")


def test_15_symlink_escape_rejected(env):
    harness, _, out_root, tmp_path = env
    outside = tmp_path / "outside"
    outside.mkdir()
    link = out_root / "e7-static-r4-s42"
    link.symlink_to(outside, target_is_directory=True)
    from cycleft.e7.execution_harness import resolve_output_dir
    with pytest.raises(OutputSafetyError, match="escapes"):
        resolve_output_dir(out_root, "e7-static-r4-s42")


# ---------------------------------------------------------------------------
# 16-18: dry-run purity
# ---------------------------------------------------------------------------


def test_16_dry_run_modifies_nothing(env):
    harness, _, out_root, tmp_path = env

    def snapshot(p: Path):
        return {str(q.relative_to(p)): (q.stat().st_mtime_ns, q.stat().st_size)
                for q in sorted(p.rglob("*")) if q.is_file()}

    anchors_before = snapshot(tmp_path)
    out_before = snapshot(out_root) if out_root.exists() else {}
    harness.dry_run()
    assert snapshot(tmp_path) == anchors_before, "anchors/inputs modified by dry-run"
    assert (snapshot(out_root) if out_root.exists() else {}) == out_before
    assert not any(out_root.iterdir()), "dry-run created output content"


def test_17_dry_run_does_not_import_model_training_path(tmp_path, capsys):
    """Subprocess: dry-run must not import torch/transformers/peft/training."""
    matrix = build_valid_matrix(tmp_path)
    build_anchors(tmp_path)
    out_root = tmp_path / "results" / "e7" / "out"
    out_root.mkdir(parents=True)
    code = (
        "import sys, json;"
        "from cycleft.e7.execution_harness import ExecutionHarness;"
        f"h = ExecutionHarness({str(matrix)!r}, {str(out_root)!r}, "
        f"repo_root={str(tmp_path)!r});"
        "h.dry_run();"
        "bad = [m for m in ('torch', 'transformers', 'peft', 'cycleft.e5', "
        "'cycleft.finetuning') if any(x == m or x.startswith(m + '.') "
        "for x in sys.modules)];"
        "print(json.dumps({'bad': bad}))"
    )
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True,
                       env={**os.environ, "PYTHONPATH": str(Path(__file__).resolve().parents[1] / "src")})
    assert r.returncode == 0, r.stderr
    assert json.loads(r.stdout.strip().splitlines()[-1])["bad"] == []


def test_18_dry_run_cannot_invoke_training_or_evaluation(env):
    harness, _, out_root, _ = env
    calls = []

    def run_fn(spec, run_dir):  # would only be called by execute()
        calls.append(spec.exec_id)
        return {}

    harness.run_fn = run_fn
    harness.dry_run()
    harness.dry_run()
    assert calls == [], "dry-run invoked the training callable"
    # execute() refuses without the explicit confirmation token
    with pytest.raises(HarnessError, match="confirmation token"):
        harness.execute("wrong-token")
    with pytest.raises(HarnessError, match="confirmation token"):
        harness.execute("")
    assert calls == []
    assert not any(out_root.iterdir())


# ---------------------------------------------------------------------------
# completion protocol, manifests, telemetry
# ---------------------------------------------------------------------------


def test_completion_protocol_full_path(env):
    harness, _, out_root, _ = env
    spec = [s for s in harness.specs() if s.exec_id == "e7-static-r4-s42"][0]
    run_dir = out_root / spec.exec_id
    run_dir.mkdir(parents=True)
    manifest = {"exec_id": spec.exec_id, "config_hash": spec.config_hash,
                "state": "RUNNING", "source_row": spec.row}
    (run_dir / MANIFEST_NAME).write_text(json.dumps(manifest))
    (run_dir / "predictions").mkdir()
    (run_dir / "execution_summary.json").write_text('{"ok": true}')
    (run_dir / "final_eval.json").write_text('{"em": 0.1}')
    telemetry = {"return_code": 0, "training_s": 1.0, "evaluation_s": 0.5,
                 "checkpoint_serialize_s": 0.1, "rank_transition_s": 0.0,
                 "peak_rss_mb": 1.0, "final_rank_schedule": list(spec.event_ranks),
                 "final_eval_metrics": {"em": 0.1}}
    harness._finalize_completed(run_dir, spec, manifest, telemetry)
    rec = harness.inspect_state(run_dir)
    assert rec["state"] == "COMPLETED" and rec["completion_marker_present"] is True
    marker = json.loads((run_dir / COMPLETION_MARKER_NAME).read_text())
    assert marker["config_hash"] == spec.config_hash
    assert marker["artifacts"]["execution_summary.json"] != ""
    assert marker["telemetry"]["final_rank_schedule"] == ["4", "4", "4"]


def test_run_manifest_contains_required_fields(env):
    harness, _, _, _ = env
    spec = harness.specs()[0]
    assert spec.config_hash and len(spec.config_hash) == 64
    plan = harness.dry_run()
    p0 = [p for p in plan if p.row_type == "NEW"][0]
    assert p0.config_hash == [s for s in harness.specs()
                              if s.exec_id == p0.exec_id][0].config_hash


def test_reuse_rows_never_scheduled_for_training(env):
    harness, _, _, _ = env
    plan = harness.dry_run()
    for p in plan:
        if p.row_type == "REUSE":
            assert p.action == "read-only reference"
            assert not p.output_path.startswith(str(harness.output_root))
            assert "anchor_" in p.output_path


def test_atomic_manifest_write_leaves_no_temp_files(env):
    harness, _, out_root, tmp_path = env
    spec = harness.specs()[0]
    run_dir = out_root / spec.exec_id
    run_dir.mkdir(parents=True)
    manifest = {"exec_id": spec.exec_id, "state": "RUNNING"}
    harness._mark_failed(run_dir, spec, manifest, reason="synthetic")
    leftovers = [p.name for p in run_dir.iterdir() if p.name.startswith(".tmp_")]
    assert leftovers == []
    assert json.loads((run_dir / MANIFEST_NAME).read_text())["state"] == "FAILED"
    assert json.loads((run_dir / MANIFEST_NAME).read_text())["failure_reason"] == "synthetic"


def test_failed_run_then_next_run_still_guards(env):
    harness, matrix, out_root, tmp_path = env
    def failing_fn(spec, run_dir):
        (run_dir / "predictions").mkdir()
        (run_dir / "execution_summary.json").write_text("{}")
        raise RuntimeError("synthetic training failure")
    h = ExecutionHarness(matrix, out_root, repo_root=tmp_path, run_fn=failing_fn)
    h.execute(EXECUTE_CONFIRM_TOKEN)
    rec = harness.inspect_state(out_root / "e7-static-r4-s42")
    assert rec["state"] == "FAILED" and "synthetic training failure" in rec["failure_reason"]
    assert not (out_root / "e7-static-r4-s42" / COMPLETION_MARKER_NAME).exists()
    # completed-run directories from a prior execution block re-execution
    def ok_fn(spec, run_dir):
        (run_dir / "predictions").mkdir()
        (run_dir / "execution_summary.json").write_text('{"ok": 1}')
        (run_dir / "final_eval.json").write_text('{"em": 0.2}')
        return {"return_code": 0}
    h2 = ExecutionHarness(matrix, out_root, repo_root=tmp_path, run_fn=ok_fn)
    with pytest.raises(OutputSafetyError, match="refusing to execute"):
        h2.execute(EXECUTE_CONFIRM_TOKEN)  # FAILED dir has artifacts -> must refuse
    rec2 = harness.inspect_state(out_root / "e7-static-r4-s42")
    assert rec2["state"] == "FAILED", "failed run must not be silently overwritten"
    assert not (out_root / "e7-static-r4-s42" / COMPLETION_MARKER_NAME).exists()
